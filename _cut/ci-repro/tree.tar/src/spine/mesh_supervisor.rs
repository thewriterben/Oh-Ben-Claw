//! Mesh supervisor — fold the LoRa mesh into the brain (Phase B).
//!
//! The inbound gateway bridge lands node messages in world memory; this loop *acts on*
//! them. Each tick it derives a per-node health view (online / degraded / offline) from
//! the mesh facts, writes it back to world memory (so reflexes, foresight, and the agent
//! can see it), and — when a node goes offline — can autonomously issue a rate-limited
//! recovery command over the mesh.
//!
//! ```text
//! perception            decision                 action
//! mesh.<node>.*  ─►  derive health  ─►  observe mesh.<node>.health
//! (world memory)     (online/degraded/    + (if offline) send recovery
//!                     offline)              mesh_command via the sink
//! ```
//!
//! The decision core ([`decide`]) is pure and unit-tested; the driver ([`tick`]) reads
//! the real store and drives the mesh command sink.

use crate::config::MeshSupervisorConfig;
use crate::memory::world::{Origin, WorldMemory};
use crate::spine::lora_gateway::{CommandSink, NodeCommand};
use serde_json::json;
use std::sync::Arc;

/// Source tag stamped on every fact the supervisor writes.
///
/// Not named `SOURCE`: this module also uses the gateway's, and the two are routinely
/// side by side — the gateway reports what came off the air, the supervisor reports
/// what it concluded from that. Naming both `SOURCE` is how a conclusion ends up
/// wearing a radio's label.
///
/// Now that source liveness can retract, this label is load-bearing rather than
/// decorative: it decides which facts stop being believed when the supervisor is
/// switched off.
pub const SUPERVISOR_SOURCE: &str = "mesh-supervisor";

/// Derived health of a mesh node.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MeshHealth {
    /// Heard recently, last command (if any) succeeded.
    Online,
    /// Heard recently, but the last command result was not ok.
    Degraded,
    /// No mesh message within the staleness window.
    Offline,
}

impl MeshHealth {
    pub fn as_str(self) -> &'static str {
        match self {
            MeshHealth::Online => "online",
            MeshHealth::Degraded => "degraded",
            MeshHealth::Offline => "offline",
        }
    }

    fn parse(s: &str) -> Option<Self> {
        match s {
            "online" => Some(Self::Online),
            "degraded" => Some(Self::Degraded),
            "offline" => Some(Self::Offline),
            _ => None,
        }
    }
}

/// A compact per-node snapshot the driver extracts from world memory for a decision.
#[derive(Debug, Clone)]
pub struct MeshNodeView {
    pub node: String,
    /// Row id of the `mesh.<node>` rollup fact this view was read from.
    ///
    /// The ids on this view exist so decisions can say what they were computed *from*.
    /// The supervisor concludes; the gateway observes; carrying the id is what lets a
    /// conclusion be withdrawn when the observation under it is.
    pub rollup_id: i64,
    /// Row id of the `cmd_result` fact behind [`Self::last_cmd_ok`], if any.
    pub cmd_result_id: Option<i64>,
    /// Row id of the current `mesh.<node>.health` fact, if any.
    pub health_id: Option<i64>,
    /// `valid_from` of the node's latest `mesh.<node>` rollup fact (ms).
    pub last_seen_ms: u64,
    /// Whether the node's latest `cmd_result` reflects a *healthy* node.
    ///
    /// Not simply the reply's `ok`: a Track 0 refusal arrives as `ok: false` but means
    /// the node enforced its own policy correctly, which is the node working. See
    /// [`cmd_result_healthy`].
    pub last_cmd_ok: Option<bool>,
    /// Previously-recorded health (so we only write on change).
    pub prev_health: Option<MeshHealth>,
    /// `valid_from` of the current `mesh.<node>.health` fact — marks when the current
    /// health began, for measuring continuous-offline duration.
    pub health_since_ms: Option<u64>,
    /// When we last sent a recovery command to this node (ms), if ever.
    pub last_recovery_ms: Option<u64>,
    /// Whether the node is currently escalated (presumed lost).
    pub escalated: bool,
}

/// A supervisor decision to apply.
#[derive(Debug, Clone, PartialEq)]
pub enum MeshDecision {
    /// Record/refresh the node's derived health (only emitted when it changes).
    Health {
        node: String,
        status: &'static str,
        reason: String,
    },
    /// Issue a recovery command to an offline node.
    Recover { node: String, cmd: NodeCommand },
    /// Escalate: the node has been offline long enough to be presumed lost (recovery
    /// stops).
    Escalate { node: String, reason: String },
    /// Clear a prior escalation: the node came back.
    ClearEscalation { node: String },
}

/// Pure decision core: from per-node views + now + config, produce the actions to apply.
/// Health is emitted only when it *changes* (no churn); recovery only for offline nodes
/// when `recover` is configured and the per-node rate limit has elapsed.
pub fn decide(
    views: &[MeshNodeView],
    now_ms: u64,
    cfg: &MeshSupervisorConfig,
) -> Vec<MeshDecision> {
    let mut out = Vec::new();
    for v in views {
        let age = now_ms.saturating_sub(v.last_seen_ms);
        let (status, reason) = if age > cfg.stale_ms {
            (MeshHealth::Offline, format!("no mesh message for {age} ms"))
        } else if v.last_cmd_ok == Some(false) {
            (
                MeshHealth::Degraded,
                "last command result was not ok".to_string(),
            )
        } else {
            (MeshHealth::Online, "healthy".to_string())
        };

        if v.prev_health != Some(status) {
            out.push(MeshDecision::Health {
                node: v.node.clone(),
                status: status.as_str(),
                reason,
            });
        }

        if status == MeshHealth::Offline {
            // Continuous-offline duration: if it was already offline, the health fact's
            // valid_from marks when it began; if it went offline this tick, that's ~now.
            let offline_since = if v.prev_health == Some(MeshHealth::Offline) {
                v.health_since_ms.unwrap_or(now_ms)
            } else {
                now_ms
            };
            let offline_for = now_ms.saturating_sub(offline_since);
            let escalate_now =
                cfg.escalate_after_ms > 0 && !v.escalated && offline_for >= cfg.escalate_after_ms;

            if escalate_now {
                out.push(MeshDecision::Escalate {
                    node: v.node.clone(),
                    reason: format!("offline for {offline_for} ms — presumed lost"),
                });
            }

            // Recovery probing. Before escalation we ping at the fast cadence to try to
            // wake the node. After escalation we do NOT give up entirely: a node that
            // only answers a direct command — its passive beacons lost to RF, say —
            // still gets a *slow* "are you back?" probe, so the escalation self-heals
            // (a reply refreshes `last_seen` and the next tick clears it). The tick that
            // escalates suppresses a redundant same-tick ping.
            if !escalate_now {
                if let Some(cmd_name) = &cfg.recover {
                    let interval = if v.escalated {
                        cfg.escalated_probe_interval_ms
                    } else {
                        cfg.min_recovery_interval_ms
                    };
                    // `escalated_probe_interval_ms == 0` opts back out of the slow probe
                    // (an escalated node is then left silent, the old behaviour).
                    let probe_enabled = !v.escalated || cfg.escalated_probe_interval_ms > 0;
                    let due = v
                        .last_recovery_ms
                        .is_none_or(|t| now_ms.saturating_sub(t) >= interval);
                    if probe_enabled && due {
                        let id = format!("sup-{}-{}", v.node, now_ms);
                        out.push(MeshDecision::Recover {
                            node: v.node.clone(),
                            cmd: NodeCommand::new(&v.node, id, cmd_name, json!({})),
                        });
                    }
                }
            }
        } else if v.escalated {
            // The node returned after being presumed lost → clear the escalation.
            out.push(MeshDecision::ClearEscalation {
                node: v.node.clone(),
            });
        }
    }
    out
}

/// Whether a node's `cmd_result` payload indicates a healthy node.
///
/// A Track 0 refusal ("safety: pin 99 not in allow-list") comes back as `ok: false`,
/// because from the command's point of view it did not succeed. But the node refusing an
/// out-of-policy write is the safety system working — arguably the single most important
/// thing the node does. Scoring it as a node fault meant every safety test marked the
/// node that passed it as `degraded`, and with the post-escalation slow probe a node
/// could be held in that wrong state indefinitely.
///
/// So refusals read as healthy here. The refusal itself is not lost — it stays in the
/// `mesh.<node>.cmd_result` fact for anyone asking what the node did, rather than what
/// state it is in.
pub fn cmd_result_healthy(value: &serde_json::Value) -> Option<bool> {
    if is_policy_refusal(value) {
        return Some(true);
    }
    value.get("ok").and_then(|v| v.as_bool())
}

/// Did the node refuse this command on policy, rather than fail it?
fn is_policy_refusal(value: &serde_json::Value) -> bool {
    // Firmware ≥ the `refused` flag says so outright.
    if value.get("refused").and_then(|v| v.as_bool()) == Some(true) {
        return true;
    }
    // Compatibility with nodes flashed before that flag existed: the on-MCU gate
    // prefixes every `SafetyViolation` with "safety:". Kept as a fallback so a
    // half-upgraded fleet doesn't mark its older nodes degraded.
    value
        .get("error")
        .and_then(|v| v.as_str())
        .is_some_and(|e| e.starts_with("safety:"))
}

/// Extract the current per-node views from world memory (rollup + last cmd_result +
/// prior health + last recovery). Mesh nodes are the `mesh.<node>` rollup entities
/// (node ids contain no dots, so a rollup splits into exactly two dot-parts).
///
/// Node discovery is **authoritative, not lexical**: a node exists because the LoRa
/// gateway heard it on the air, so the rollup fact must carry the gateway's source.
/// The shape of an entity name is not evidence of a radio.
///
/// The check is on [`Origin::Observed`] rather than on the source string. Both work
/// today — provenance is stamped by the framework, so an agent cannot claim to be
/// `lora-gateway` (see `tools::builtin::world::AGENT_SOURCE`) — but origin says what we
/// actually mean. "Something reported this off a wire" is the property that makes a node
/// real; "a component called `lora-gateway` wrote it" only implies that by convention.
///
/// It is also the stronger check. A source comparison cannot see when a *trusted*
/// component relays untrusted content — the confused-deputy case that `power` and
/// `sensing` exhibit — whereas origin travels with the content from wherever it entered.
///
/// This matters because `mesh.*` is a shared namespace. Anything else writing a
/// two-part fact under it — the supervisor's own `mesh.escalated_count` aggregate, or
/// (bench, 2026-07-17) a System 2 incident note at `mesh.escalation_status` — used to
/// be mis-parsed as a phantom node. A phantom never transmits, so it goes offline,
/// gets escalated, and pins `escalated_count >= 1` forever: the `safe-mesh-node-lost`
/// reflex then fires every tick, waking System 2, which records another note. The
/// agent manufactures its own emergency and reports it in a loop. Sourcing discovery
/// at the radio closes that loop at the root, rather than blacklisting names one at a
/// time as they appear.
pub fn snapshot(world: &WorldMemory) -> Vec<MeshNodeView> {
    let entities = world.entities().unwrap_or_default();
    let mut views = Vec::new();
    for e in entities {
        let parts: Vec<&str> = e.split('.').collect();
        if parts.len() != 2 || parts[0] != "mesh" {
            continue;
        }
        let node = parts[1].to_string();
        // Heard over the air, or it is not a node.
        let (last_seen_ms, rollup_id) = match world.current(&e).ok().flatten() {
            Some(f) if f.origin == Origin::Observed => (f.valid_from, f.id),
            _ => continue,
        };
        let cmd_result_fact = world
            .current(&format!("mesh.{node}.cmd_result"))
            .ok()
            .flatten();
        let cmd_result_id = cmd_result_fact.as_ref().map(|f| f.id);
        let last_cmd_ok = cmd_result_fact
            .as_ref()
            .and_then(|f| cmd_result_healthy(&f.value));
        let health_fact = world.current(&format!("mesh.{node}.health")).ok().flatten();
        let health_id = health_fact.as_ref().map(|f| f.id);
        let prev_health = health_fact.as_ref().and_then(|f| {
            f.value
                .get("status")
                .and_then(|v| v.as_str())
                .and_then(MeshHealth::parse)
        });
        let health_since_ms = health_fact.as_ref().map(|f| f.valid_from);
        let last_recovery_ms = world
            .current(&format!("mesh.{node}.recovery"))
            .ok()
            .flatten()
            .map(|f| f.valid_from);
        let escalated = world
            .current(&format!("mesh.{node}.escalation"))
            .ok()
            .flatten()
            .and_then(|f| {
                f.value
                    .get("status")
                    .and_then(|v| v.as_str())
                    .map(|s| s == "escalated")
            })
            .unwrap_or(false);
        views.push(MeshNodeView {
            node,
            rollup_id,
            cmd_result_id,
            health_id,
            last_seen_ms,
            last_cmd_ok,
            prev_health,
            health_since_ms,
            last_recovery_ms,
            escalated,
        });
    }
    views
}

/// The last `limit` RSSI readings for a node, oldest→newest, for a sparkline.
///
/// Reads the node's `mesh.<node>` rollup history and pulls each fact's `rssi_dbm`
/// (skipping facts that carried no RSSI). Returns at most `limit` values.
pub fn rssi_series(world: &WorldMemory, node: &str, limit: usize) -> Vec<i64> {
    let mut series: Vec<i64> = world
        .history(&format!("mesh.{node}"))
        .unwrap_or_default()
        .into_iter()
        .filter_map(|f| f.value.get("rssi_dbm").and_then(|r| r.as_i64()))
        .collect();
    if series.len() > limit {
        series = series.split_off(series.len() - limit); // keep the newest `limit`
    }
    series
}

/// Recent mesh-relevant escalations from the notifications log-of-record, newest first.
///
/// Reads the `notifications.escalation` history (the durable channel written by the
/// notifier), drops periodic digest entries, classifies each by severity, and returns up
/// to `limit` entries as `{ ts_ms, age_s, severity, reason }` (reason trimmed to its
/// first sentence). Shared by the `mesh_status` tool and the gateway route.
pub fn recent_escalations(world: &WorldMemory, limit: usize) -> Vec<serde_json::Value> {
    use crate::agent::notify::{Severity, DIGEST_PREFIX};
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);
    let mut out: Vec<serde_json::Value> = world
        .history("notifications.escalation")
        .unwrap_or_default()
        .into_iter()
        .filter_map(|f| {
            f.value
                .get("reason")
                .and_then(|r| r.as_str())
                .map(|r| (f.valid_from, r.to_string()))
        })
        .filter(|(_, r)| !r.starts_with(DIGEST_PREFIX))
        .map(|(ts, reason)| {
            let head = reason
                .split_once(". ")
                .map(|(h, _)| h)
                .unwrap_or(&reason)
                .to_string();
            json!({
                "ts_ms": ts,
                "age_s": now.saturating_sub(ts) / 1000,
                "severity": Severity::classify(&reason).as_str(),
                "reason": head,
            })
        })
        .collect();
    out.reverse(); // history is oldest-first; surface newest first
    out.truncate(limit);
    out
}

/// Build the read-only mesh status JSON — the single source of truth shared by the
/// `mesh_status` agent tool and the `GET /api/v1/mesh/status` gateway route.
///
/// Returns `{ summary: { nodes, online, degraded, offline, escalated }, nodes: [ … ],
/// escalations: [ … ] }`, where each node carries `health`, `escalated`, `rssi_dbm`,
/// `last_type`, `age_s` (seconds since last heard), and `last_cmd_ok`, and each
/// escalation carries `ts_ms`, `age_s`, `severity`, and `reason`.
pub fn status_json(world: &WorldMemory) -> serde_json::Value {
    let views = snapshot(world);
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0);

    let (mut online, mut degraded, mut offline, mut escalated) = (0u64, 0u64, 0u64, 0u64);
    let mut nodes = Vec::with_capacity(views.len());
    for v in &views {
        let health = v.prev_health.map(|h| h.as_str()).unwrap_or("unknown");
        match health {
            "online" => online += 1,
            "degraded" => degraded += 1,
            "offline" => offline += 1,
            _ => {}
        }
        if v.escalated {
            escalated += 1;
        }
        let rollup = world.current(&format!("mesh.{}", v.node)).ok().flatten();
        let rssi = rollup
            .as_ref()
            .and_then(|f| f.value.get("rssi_dbm").and_then(|r| r.as_i64()));
        let last_type = rollup
            .as_ref()
            .and_then(|f| f.value.get("last_type").and_then(|t| t.as_str()))
            .unwrap_or("-")
            .to_string();
        nodes.push(json!({
            "node": v.node,
            "health": health,
            "escalated": v.escalated,
            "rssi_dbm": rssi,
            "rssi_history": rssi_series(world, &v.node, 24),
            "last_type": last_type,
            "age_s": now.saturating_sub(v.last_seen_ms) / 1000,
            "last_cmd_ok": v.last_cmd_ok,
        }));
    }

    json!({
        "summary": {
            "nodes": views.len(),
            "online": online,
            "degraded": degraded,
            "offline": offline,
            "escalated": escalated,
        },
        "nodes": nodes,
        "escalations": recent_escalations(world, 10),
    })
}

/// One supervisor tick: snapshot → decide → apply. Health decisions are observed into
/// world memory; recovery decisions are sent through `sink` (when present) and recorded.
/// Returns the number of actions applied.
pub async fn tick(
    world: &WorldMemory,
    sink: Option<&Arc<dyn CommandSink>>,
    cfg: &MeshSupervisorConfig,
    now_ms: u64,
) -> usize {
    let views = snapshot(world);
    let decisions = decide(&views, now_ms, cfg);
    let mut applied = 0;

    // Every fact written below is a *conclusion*, and every one of them has inputs the
    // supervisor is holding at the moment it writes. Declaring them builds the chain
    //
    //     mesh.<node>            (lora-gateway, observed off the air)
    //       └─ mesh.<node>.health        (supervisor concluded)
    //            ├─ mesh.<node>.escalation
    //            │    └─ mesh.escalated_count
    //            └─ mesh.<node>.recovery
    //
    // which is what makes "the radio is gone, so none of this is grounded any more" a
    // walk rather than a judgement call. Without it, retiring the gateway closes the
    // rollups and leaves every conclusion drawn from them standing.
    let by_node: std::collections::HashMap<&str, &MeshNodeView> =
        views.iter().map(|v| (v.node.as_str(), v)).collect();
    // Health facts written during this tick supersede the ones the snapshot saw, so
    // decisions later in the same tick must point at the new row, not the stale one.
    let mut health_ids: std::collections::HashMap<String, i64> = views
        .iter()
        .filter_map(|v| v.health_id.map(|id| (v.node.clone(), id)))
        .collect();

    for d in decisions {
        match d {
            MeshDecision::Health {
                node,
                status,
                reason,
            } => {
                // Health rests on the radio evidence it was derived from: when the node
                // was last heard, and how it answered the last command.
                let mut support = Vec::new();
                if let Some(v) = by_node.get(node.as_str()) {
                    support.push(v.rollup_id);
                    support.extend(v.cmd_result_id);
                }
                if let Ok(f) = world.observe_derived_from(
                    &format!("mesh.{node}.health"),
                    json!({ "status": status, "reason": reason, "ts_ms": now_ms }),
                    now_ms,
                    now_ms,
                    SUPERVISOR_SOURCE,
                    &support,
                ) {
                    health_ids.insert(node.clone(), f.id);
                }
                applied += 1;
            }
            MeshDecision::Recover { node, cmd } => {
                if let Some(s) = sink {
                    if s.send_command(&cmd).await.is_ok() {
                        let support: Vec<i64> =
                            health_ids.get(&node).copied().into_iter().collect();
                        let _ = world.observe_derived_from(
                            &format!("mesh.{node}.recovery"),
                            json!({ "cmd": cmd.cmd, "id": cmd.id, "ts_ms": now_ms }),
                            now_ms,
                            now_ms,
                            SUPERVISOR_SOURCE,
                            &support,
                        );
                        applied += 1;
                    }
                }
            }
            MeshDecision::Escalate { node, reason } => {
                tracing::warn!(node = %node, "mesh supervisor: node presumed lost — {reason}");
                // "Presumed lost" is a conclusion about a health state that has persisted.
                // If that health fact stops being believed, so must this.
                let support: Vec<i64> = health_ids.get(&node).copied().into_iter().collect();
                let _ = world.observe_derived_from(
                    &format!("mesh.{node}.escalation"),
                    json!({ "status": "escalated", "reason": reason, "ts_ms": now_ms }),
                    now_ms,
                    now_ms,
                    SUPERVISOR_SOURCE,
                    &support,
                );
                applied += 1;
            }
            MeshDecision::ClearEscalation { node } => {
                tracing::info!(node = %node, "mesh supervisor: node returned — escalation cleared");
                // Clearing rests on the *fresh* rollup — the node transmitting again is
                // the evidence, not the health rollup computed from it.
                let support: Vec<i64> = by_node
                    .get(node.as_str())
                    .map(|v| vec![v.rollup_id])
                    .unwrap_or_default();
                let _ = world.observe_derived_from(
                    &format!("mesh.{node}.escalation"),
                    json!({ "status": "cleared", "ts_ms": now_ms }),
                    now_ms,
                    now_ms,
                    SUPERVISOR_SOURCE,
                    &support,
                );
                applied += 1;
            }
        }
    }

    // Aggregate signal for the reflex engine (health-driven reflex): the number of
    // nodes currently presumed lost. The standard `safe-mesh-node-lost` reflex rule
    // watches `mesh.escalated_count` and escalates to System 2. Recomputed after the
    // decisions above and written only on change (so a plain number, not churn).
    if !views.is_empty() {
        // Record *what the count was computed from* — the JTMS in-list. This loop
        // already read every per-node escalation fact and used to throw the ids away,
        // which is precisely why a disabled supervisor could leave `escalated_count = 2`
        // standing with nothing underneath it while the reflex kept firing on it.
        //
        // Every escalation fact consulted goes in the list, not only the escalated ones:
        // a count of 1 depends on the nodes that were *not* escalated just as much as on
        // the one that was — change either and the number changes.
        //
        // When no node has an escalation fact yet the list is empty, which claims the
        // count is self-standing. It very nearly is: all that is under it then is the
        // supervisor having run, and that becomes explicit support once source-liveness
        // markers land.
        let mut support: Vec<i64> = Vec::new();
        let mut escalated_count: u64 = 0;
        for v in &views {
            if let Some(f) = world
                .current(&format!("mesh.{}.escalation", v.node))
                .ok()
                .flatten()
            {
                if f.value.get("status").and_then(|s| s.as_str()) == Some("escalated") {
                    escalated_count += 1;
                }
                support.push(f.id);
            }
        }
        let prev = world
            .current("mesh.escalated_count")
            .ok()
            .flatten()
            .and_then(|f| f.value.as_u64());
        if prev != Some(escalated_count) {
            let _ = world.observe_derived_from(
                "mesh.escalated_count",
                json!(escalated_count),
                now_ms,
                now_ms,
                SUPERVISOR_SOURCE,
                &support,
            );
        }
    }

    applied
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::spine::lora_gateway::SOURCE;
    use std::sync::Mutex;

    fn cfg(recover: Option<&str>) -> MeshSupervisorConfig {
        MeshSupervisorConfig {
            enabled: true,
            stale_ms: 5_000,
            tick_ms: 5_000,
            recover: recover.map(str::to_string),
            min_recovery_interval_ms: 30_000,
            escalate_after_ms: 0,
            escalated_probe_interval_ms: 300_000,
        }
    }

    fn view(node: &str, last_seen_ms: u64) -> MeshNodeView {
        MeshNodeView {
            node: node.to_string(),
            // `decide` is pure and never reads these; they exist so the driver can
            // record what it derived a conclusion from. Zero is a deliberate tell: any
            // test that starts caring about support must build a real store.
            rollup_id: 0,
            cmd_result_id: None,
            health_id: None,
            last_seen_ms,
            last_cmd_ok: None,
            prev_health: None,
            health_since_ms: None,
            last_recovery_ms: None,
            escalated: false,
        }
    }

    #[test]
    fn a_fresh_node_is_online_and_needs_no_recovery() {
        let d = decide(&[view("n", 10_000)], 11_000, &cfg(Some("capabilities")));
        assert_eq!(d.len(), 1);
        assert!(matches!(
            &d[0],
            MeshDecision::Health {
                status: "online",
                ..
            }
        ));
    }

    #[test]
    fn a_stale_node_goes_offline_and_is_recovered() {
        // last seen at 1_000, now 11_000, stale_ms 5_000 → offline.
        let d = decide(&[view("n", 1_000)], 11_000, &cfg(Some("capabilities")));
        assert!(d.iter().any(|x| matches!(
            x,
            MeshDecision::Health {
                status: "offline",
                ..
            }
        )));
        let rec = d.iter().find_map(|x| match x {
            MeshDecision::Recover { cmd, .. } => Some(cmd),
            _ => None,
        });
        let rec = rec.expect("offline node is recovered");
        assert_eq!(rec.cmd, "capabilities");
        assert_eq!(rec.to, "n");
    }

    #[test]
    fn recovery_is_rate_limited_per_node() {
        let mut v = view("n", 1_000);
        v.last_recovery_ms = Some(10_500); // recovered 500 ms ago; interval is 30 s
        let d = decide(&[v], 11_000, &cfg(Some("capabilities")));
        assert!(
            !d.iter().any(|x| matches!(x, MeshDecision::Recover { .. })),
            "within the cooldown"
        );
    }

    #[test]
    fn observe_only_when_no_recover_command_is_set() {
        let d = decide(&[view("n", 1_000)], 11_000, &cfg(None));
        assert!(
            d.iter().all(|x| matches!(x, MeshDecision::Health { .. })),
            "no recovery without a command"
        );
    }

    #[test]
    fn a_failed_command_marks_the_node_degraded() {
        let mut v = view("n", 10_500); // fresh
        v.last_cmd_ok = Some(false);
        let d = decide(&[v], 11_000, &cfg(None));
        assert!(matches!(
            &d[0],
            MeshDecision::Health {
                status: "degraded",
                ..
            }
        ));
    }

    #[test]
    fn health_is_not_rewritten_when_unchanged() {
        let mut v = view("n", 10_500);
        v.prev_health = Some(MeshHealth::Online);
        let d = decide(&[v], 11_000, &cfg(None));
        assert!(d.is_empty(), "online→online produces no churn");
    }

    struct MockSink {
        sent: Mutex<Vec<NodeCommand>>,
    }
    #[async_trait::async_trait]
    impl CommandSink for MockSink {
        async fn send_command(&self, cmd: &NodeCommand) -> anyhow::Result<()> {
            self.sent.lock().unwrap().push(cmd.clone());
            Ok(())
        }
    }

    #[tokio::test]
    async fn tick_marks_offline_and_sends_one_recovery_then_backs_off() {
        let world = WorldMemory::open_in_memory().unwrap();
        // A node last heard at t=1_000.
        world
            .observe_as(
                "mesh.node-x",
                json!({ "last_type": "link_state", "rssi_dbm": -50, "seq": 1, "src": "2A" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();

        let mock = Arc::new(MockSink {
            sent: Mutex::new(Vec::new()),
        });
        let sink: Arc<dyn CommandSink> = mock.clone();
        let c = cfg(Some("capabilities"));

        // First tick well past the staleness window → offline + one recovery.
        let n = tick(&world, Some(&sink), &c, 11_000).await;
        assert!(n >= 2, "health + recovery applied");
        let h = world.current("mesh.node-x.health").unwrap().unwrap();
        assert_eq!(h.value["status"], json!("offline"));
        assert_eq!(mock.sent.lock().unwrap().len(), 1);
        assert_eq!(mock.sent.lock().unwrap()[0].cmd, "capabilities");
        assert_eq!(mock.sent.lock().unwrap()[0].to, "node-x");

        // A second tick moments later: still offline (health unchanged → no rewrite) and
        // recovery is rate-limited → no new command.
        let n2 = tick(&world, Some(&sink), &c, 11_500).await;
        assert_eq!(n2, 0, "no churn, no repeat recovery within the cooldown");
        assert_eq!(mock.sent.lock().unwrap().len(), 1);
    }

    fn esc_cfg() -> MeshSupervisorConfig {
        let mut c = cfg(Some("capabilities"));
        c.escalate_after_ms = 20_000;
        c
    }

    fn offline_view(node: &str, offline_since: u64) -> MeshNodeView {
        let mut v = view(node, offline_since);
        v.prev_health = Some(MeshHealth::Offline);
        v.health_since_ms = Some(offline_since);
        v
    }

    #[test]
    fn a_node_offline_past_the_threshold_is_escalated_and_stops_pinging() {
        // offline since 1_000, now 30_000 → offline_for 29_000 >= 20_000.
        let d = decide(&[offline_view("n", 1_000)], 30_000, &esc_cfg());
        assert!(
            d.iter().any(|x| matches!(x, MeshDecision::Escalate { .. })),
            "escalates"
        );
        assert!(
            !d.iter().any(|x| matches!(x, MeshDecision::Recover { .. })),
            "gives up pinging"
        );
    }

    #[test]
    fn an_escalated_node_is_not_re_escalated() {
        // Escalated + still offline + last probe recent → no re-escalation, no health
        // churn, and not yet due for the slow probe.
        let mut v = offline_view("n", 1_000);
        v.escalated = true;
        v.last_recovery_ms = Some(29_500); // probed 500 ms ago; slow interval is 300 s
        let d = decide(&[v], 30_000, &esc_cfg());
        assert!(
            d.is_empty(),
            "no re-escalation, no health churn, within the slow cooldown"
        );
    }

    #[test]
    fn an_escalated_node_is_slowly_probed_not_abandoned() {
        // The self-healing probe: an escalated node whose beacons are lost to RF but
        // which still answers a direct command must keep getting a slow "are you back?"
        // ping, so it can recover on its own.
        let mut v = offline_view("n", 1_000);
        v.escalated = true;
        v.last_recovery_ms = Some(1_000); // last probed at t=1_000
                                          // Not yet due at +299 s (slow interval is 300 s).
        let early = decide(&[v.clone()], 300_000, &esc_cfg());
        assert!(
            !early
                .iter()
                .any(|x| matches!(x, MeshDecision::Recover { .. })),
            "within the slow cooldown"
        );
        // Due at +300 s.
        let due = decide(&[v], 301_500, &esc_cfg());
        assert!(
            due.iter()
                .any(|x| matches!(x, MeshDecision::Recover { .. })),
            "slow probe fires when due"
        );
        assert!(
            !due.iter()
                .any(|x| matches!(x, MeshDecision::Escalate { .. })),
            "but never re-escalates"
        );
    }

    #[test]
    fn setting_the_escalated_probe_to_zero_restores_give_up_on_escalation() {
        // Opt-out: `escalated_probe_interval_ms == 0` leaves an escalated node silent.
        let mut c = esc_cfg();
        c.escalated_probe_interval_ms = 0;
        let mut v = offline_view("n", 1_000);
        v.escalated = true;
        let d = decide(&[v], 1_000_000, &c);
        assert!(
            d.is_empty(),
            "no probe, no churn — the old give-up behaviour"
        );
    }

    #[test]
    fn recovery_continues_before_the_escalation_threshold() {
        // offline_for 9_000 < 20_000 → still recovering, not escalated.
        let d = decide(&[offline_view("n", 1_000)], 10_000, &esc_cfg());
        assert!(d.iter().any(|x| matches!(x, MeshDecision::Recover { .. })));
        assert!(!d.iter().any(|x| matches!(x, MeshDecision::Escalate { .. })));
    }

    #[test]
    fn a_returning_node_clears_its_escalation() {
        // fresh (online) but previously escalated → clear.
        let mut v = view("n", 29_500);
        v.prev_health = Some(MeshHealth::Offline);
        v.escalated = true;
        let d = decide(&[v], 30_000, &esc_cfg());
        assert!(d
            .iter()
            .any(|x| matches!(x, MeshDecision::ClearEscalation { .. })));
    }

    #[tokio::test]
    async fn tick_escalates_a_long_offline_node_then_clears_on_return() {
        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n",
                json!({ "last_type": "link_state" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe(
                "mesh.n.health",
                json!({ "status": "offline", "reason": "x" }),
                1_000,
                1_000,
                "test",
            )
            .unwrap();
        let c = esc_cfg();
        let mock = Arc::new(MockSink {
            sent: Mutex::new(Vec::new()),
        });
        let sink: Arc<dyn CommandSink> = mock.clone();

        // Offline for 29 s (>= 20 s threshold) → escalate, no recovery ping.
        tick(&world, Some(&sink), &c, 30_000).await;
        assert_eq!(
            world.current("mesh.n.escalation").unwrap().unwrap().value["status"],
            json!("escalated")
        );
        assert_eq!(mock.sent.lock().unwrap().len(), 0, "escalated → no ping");

        // Node returns (fresh rollup) → escalation cleared.
        world
            .observe_as(
                "mesh.n",
                json!({ "last_type": "link_state" }),
                30_500,
                30_500,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        tick(&world, Some(&sink), &c, 31_000).await;
        assert_eq!(
            world.current("mesh.n.escalation").unwrap().unwrap().value["status"],
            json!("cleared")
        );
    }

    #[tokio::test]
    async fn escalation_raises_the_count_that_drives_a_reflex() {
        use crate::agent::reflex::{Action, ReflexEngine};
        use crate::agent::safing::{standard_safing_rules, SafingOptions};

        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n",
                json!({ "last_type": "link_state" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe(
                "mesh.n.health",
                json!({ "status": "offline" }),
                1_000,
                1_000,
                "test",
            )
            .unwrap();
        let mut c = esc_cfg();
        c.recover = None; // observe-only; escalation is time-based and still fires

        // Supervisor escalates the long-offline node → publishes the aggregate count.
        tick(&world, None, &c, 30_000).await;
        assert_eq!(
            world
                .current("mesh.escalated_count")
                .unwrap()
                .unwrap()
                .value
                .as_u64(),
            Some(1)
        );

        // A standard safing engine reads world memory and fires the health-driven
        // escalate — the mesh's presumed-lost node wakes System 2.
        let engine = ReflexEngine::new(standard_safing_rules(&SafingOptions::default()));
        let fired = engine.tick(&world, 40_000).unwrap();
        assert!(
            fired.iter().any(|f| f.rule_id == "safe-mesh-node-lost"
                && matches!(f.action, Action::Escalate { .. })),
            "mesh health drives a reflex escalation"
        );
    }

    #[tokio::test]
    async fn the_count_records_the_escalation_facts_it_was_computed_from() {
        // The July bench bug in miniature. `mesh.escalated_count = 2` outlived the
        // supervisor that computed it because nothing recorded what it rested on. Now
        // the count carries its in-list, so "what did I believe because of this node?"
        // is a walk rather than an archaeology exercise.
        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n",
                json!({ "last_type": "link_state" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe(
                "mesh.n.health",
                json!({ "status": "offline" }),
                1_000,
                1_000,
                "test",
            )
            .unwrap();
        let mut c = esc_cfg();
        c.recover = None;

        tick(&world, None, &c, 30_000).await;

        let esc = world.current("mesh.n.escalation").unwrap().unwrap();
        let count = world.current("mesh.escalated_count").unwrap().unwrap();
        assert_eq!(count.value.as_u64(), Some(1));
        assert_eq!(
            count.derived_from,
            Some(vec![vec![esc.id]]),
            "the count names the escalation fact under it"
        );
        // And the edge is walkable from the other end — this is the query that was
        // impossible before: what rests on this node's escalation?
        let deps = world.dependents(esc.id).unwrap();
        assert_eq!(deps.len(), 1);
        assert_eq!(deps[0].entity, "mesh.escalated_count");
    }

    #[tokio::test]
    async fn losing_the_radio_unwinds_everything_the_supervisor_concluded() {
        // End-to-end, through the real tick rather than a hand-built chain: the gateway
        // observes a node, the supervisor concludes health → escalation → count on top
        // of it, and then the radio goes away. The supervisor is still running and still
        // willing; it simply has nothing left to have concluded from.
        use crate::memory::liveness::{stopped, Stopped};
        use crate::spine::lora_gateway::SOURCE as GATEWAY_SOURCE;

        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n",
                json!({ "last_type": "link_state" }),
                1_000,
                1_000,
                GATEWAY_SOURCE,
                Origin::Observed,
            )
            .unwrap();
        let mut c = esc_cfg();
        c.recover = None;

        tick(&world, None, &c, 30_000).await; // health: offline
        tick(&world, None, &c, 160_000).await; // escalate + count

        assert_eq!(
            world
                .current("mesh.escalated_count")
                .unwrap()
                .unwrap()
                .value
                .as_u64(),
            Some(1)
        );
        // Every link in the chain declares its support — this is what makes the sweep
        // below a walk rather than a guess.
        for e in ["mesh.n.health", "mesh.n.escalation", "mesh.escalated_count"] {
            assert!(
                world.current(e).unwrap().unwrap().derived_from.is_some(),
                "{e} did not record what it was derived from"
            );
        }

        let sweep = stopped(
            &world,
            GATEWAY_SOURCE,
            Stopped::Retired,
            200_000,
            "no COM port",
        )
        .unwrap();

        assert_eq!(
            sweep.closed.len(),
            1,
            "only the radio's own fact was its own"
        );
        assert_eq!(sweep.unsupported.len(), 3, "health, escalation, count");
        for e in ["mesh.n.health", "mesh.n.escalation", "mesh.escalated_count"] {
            assert!(
                world.current(e).unwrap().is_none(),
                "{e} outlived the radio"
            );
        }

        // Undercut, not rebutted: the count is not now zero, it is not held at all.
        assert_eq!(
            world
                .at("mesh.escalated_count", 170_000)
                .unwrap()
                .unwrap()
                .value
                .as_u64(),
            Some(1)
        );
    }

    #[tokio::test]
    async fn an_agent_note_under_mesh_never_becomes_a_node() {
        // Bench regression, 2026-07-17. The `safe-mesh-node-lost` playbook tells System 2
        // to record the loss; it filed the note at `mesh.escalation_status`, which
        // lexical discovery read back as a node. The phantom can't transmit → offline →
        // escalated → `escalated_count >= 1` forever → the reflex fires every tick →
        // wakes System 2 → another note. The agent invents an emergency and reports it
        // in a loop. Discovery is sourced at the radio, so the note stays a note.
        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n1",
                json!({ "last_type": "reflex" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe_as(
                "mesh.escalation_status",
                json!({ "nodes_escalated": ["n1"], "action_required": "operator_intervention" }),
                1_000,
                1_000,
                "agent",
                Origin::Asserted, // what an LLM write actually is
            )
            .unwrap();

        let views = snapshot(&world);
        assert_eq!(views.len(), 1, "the agent's own note is not a radio");
        assert_eq!(views[0].node, "n1");

        // And it is never escalated, so it cannot pin the reflex on.
        let mut c = esc_cfg();
        c.recover = None;
        tick(&world, None, &c, 200_000).await;
        assert!(
            world
                .current("mesh.escalation_status.escalation")
                .unwrap()
                .is_none(),
            "a note is never presumed lost"
        );
        let v = status_json(&world);
        assert_eq!(
            v["summary"]["nodes"],
            json!(1),
            "no phantom in the fleet view"
        );
    }

    #[test]
    fn a_track_0_refusal_is_not_a_node_fault() {
        // The reply that came home over LoRa on 2026-07-17, verbatim in shape. `ok` is
        // false because the write did not happen — but the node refusing an out-of-policy
        // pin is the safety system working, not a malfunction.
        let refused = json!({
            "type": "cmd_result",
            "node_id": "obc-esp32-s3-001",
            "ok": false,
            "refused": true,
            "error": "safety: pin 99 not in allow-list",
        });
        assert_eq!(
            cmd_result_healthy(&refused),
            Some(true),
            "a refusal is the node working"
        );

        // A genuine failure still reads as a fault.
        let failed = json!({
            "type": "cmd_result", "ok": false,
            "error": "gpio_set_level failed for pin 2 with error 258",
        });
        assert_eq!(cmd_result_healthy(&failed), Some(false));

        // Success is success; a reply with no `ok` tells us nothing.
        assert_eq!(cmd_result_healthy(&json!({"ok": true})), Some(true));
        assert_eq!(cmd_result_healthy(&json!({"result": "x"})), None);
    }

    #[test]
    fn a_refusal_from_firmware_without_the_flag_is_still_not_a_fault() {
        // Nodes flashed before the `refused` flag only signal a refusal by the gate's
        // "safety:" prefix. A half-upgraded fleet must not mark its older nodes degraded.
        let old = json!({
            "type": "cmd_result", "ok": false,
            "error": "safety: value 7 out of range (min=Some(0), max=Some(1))",
        });
        assert_eq!(cmd_result_healthy(&old), Some(true));
        let old_rate = json!({
            "type": "cmd_result", "ok": false,
            "error": "safety: rate limit (12ms since last, min 500ms)",
        });
        assert_eq!(cmd_result_healthy(&old_rate), Some(true));
    }

    #[test]
    fn a_refused_command_does_not_degrade_the_node_end_to_end() {
        // The bug in full: safety-testing a node used to mark it degraded.
        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n",
                json!({ "last_type": "cmd_result" }),
                10_000,
                10_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe(
                "mesh.n.cmd_result",
                json!({ "ok": false, "refused": true, "error": "safety: pin 99 not in allow-list" }),
                10_000,
                10_000,
                SOURCE,
            )
            .unwrap();

        let views = snapshot(&world);
        assert_eq!(views.len(), 1);
        assert_eq!(views[0].last_cmd_ok, Some(true));

        // Fresh + refusal → online, not degraded.
        let d = decide(&views, 11_000, &cfg(None));
        assert!(
            matches!(
                &d[0],
                MeshDecision::Health {
                    status: "online",
                    ..
                }
            ),
            "the node that enforced its limits is healthy, got {:?}",
            d[0]
        );
    }

    #[test]
    fn a_relayed_fact_under_the_gateways_own_source_is_still_not_a_node() {
        // What switching from source to origin actually buys. A source comparison sees
        // only "who wrote this", so a trusted component relaying agent-supplied content
        // passes it — the confused-deputy case `power` and `sensing` exhibit. Origin
        // travels with the content from wherever it entered, so the relay is visible
        // even when the writer is the gateway itself.
        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.real",
                json!({ "last_type": "beacon" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe_as(
                "mesh.relayed",
                json!({ "last_type": "beacon" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Asserted,
            )
            .unwrap();

        let nodes: Vec<String> = snapshot(&world).into_iter().map(|v| v.node).collect();
        assert_eq!(
            nodes,
            vec!["real"],
            "only what was actually heard is a node"
        );
    }

    #[test]
    fn snapshot_ignores_the_escalated_count_aggregate() {
        // Regression: `mesh.escalated_count` is a bare counter with two dot-parts, so it
        // must NOT be mistaken for a `mesh.<node>` rollup (which would appear as a
        // phantom "online" node from the tick after it is first written).
        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n1",
                json!({ "last_type": "reflex" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe(
                "mesh.escalated_count",
                json!(0),
                1_000,
                1_000,
                SUPERVISOR_SOURCE,
            )
            .unwrap();

        let views = snapshot(&world);
        assert_eq!(views.len(), 1, "only the real node is a node");
        assert_eq!(views[0].node, "n1");
        // And the status JSON shows exactly one node, not the aggregate.
        let v = status_json(&world);
        assert_eq!(v["summary"]["nodes"], json!(1));
    }

    #[test]
    fn status_json_matches_the_mesh_status_shape() {
        // The gateway route and the mesh_status tool both call status_json — one SSOT.
        let world = WorldMemory::open_in_memory().unwrap();
        world
            .observe_as(
                "mesh.n1",
                json!({ "last_type": "reflex", "rssi_dbm": -72 }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe(
                "mesh.n1.health",
                json!({ "status": "online" }),
                1_000,
                1_000,
                "t",
            )
            .unwrap();
        // A second node that is offline and escalated.
        world
            .observe_as(
                "mesh.n2",
                json!({ "last_type": "-" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe(
                "mesh.n2.health",
                json!({ "status": "offline" }),
                1_000,
                1_000,
                "t",
            )
            .unwrap();
        world
            .observe(
                "mesh.n2.escalation",
                json!({ "status": "escalated" }),
                1_000,
                1_000,
                "t",
            )
            .unwrap();

        let v = status_json(&world);
        assert_eq!(v["summary"]["nodes"], json!(2));
        assert_eq!(v["summary"]["online"], json!(1));
        assert_eq!(v["summary"]["offline"], json!(1));
        assert_eq!(v["summary"]["escalated"], json!(1));

        let nodes = v["nodes"].as_array().unwrap();
        let n1 = nodes.iter().find(|n| n["node"] == json!("n1")).unwrap();
        assert_eq!(n1["health"], json!("online"));
        assert_eq!(n1["rssi_dbm"], json!(-72));
        assert_eq!(n1["last_type"], json!("reflex"));
        assert_eq!(n1["escalated"], json!(false));
        let n2 = nodes.iter().find(|n| n["node"] == json!("n2")).unwrap();
        assert_eq!(n2["health"], json!("offline"));
        assert_eq!(n2["escalated"], json!(true));
        assert!(n2["rssi_dbm"].is_null());
        // Escalations feed is present (empty here — no notifications logged).
        assert_eq!(v["escalations"], json!([]));
    }

    #[test]
    fn rssi_series_keeps_the_newest_readings_oldest_first() {
        let world = WorldMemory::open_in_memory().unwrap();
        // Four rollups for n1; one carries no rssi and is skipped.
        world
            .observe_as(
                "mesh.n1",
                json!({ "rssi_dbm": -60 }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe_as(
                "mesh.n1",
                json!({ "rssi_dbm": -70 }),
                2_000,
                2_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe_as(
                "mesh.n1",
                json!({ "last_type": "reflex" }),
                3_000,
                3_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        world
            .observe_as(
                "mesh.n1",
                json!({ "rssi_dbm": -80 }),
                4_000,
                4_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();

        let full = rssi_series(&world, "n1", 24);
        assert_eq!(
            full,
            vec![-60, -70, -80],
            "oldest→newest, rssi-less fact skipped"
        );
        // Limit keeps the newest N.
        let last2 = rssi_series(&world, "n1", 2);
        assert_eq!(last2, vec![-70, -80]);

        // Surfaced per-node in status_json.
        let v = status_json(&world);
        let n1 = v["nodes"]
            .as_array()
            .unwrap()
            .iter()
            .find(|n| n["node"] == json!("n1"))
            .unwrap();
        assert_eq!(n1["rssi_history"], json!([-60, -70, -80]));
    }

    #[test]
    fn recent_escalations_are_newest_first_and_skip_digests() {
        let world = WorldMemory::open_in_memory().unwrap();
        // Two real escalations + one periodic digest that must be filtered out.
        world
            .observe(
                "notifications.escalation",
                json!({ "reason": "node n1 offline. run mesh_status" }),
                1_000,
                1_000,
                "notify",
            )
            .unwrap();
        world
            .observe(
                "notifications.escalation",
                json!({ "reason": "node n2 presumed lost. escalate" }),
                2_000,
                2_000,
                "notify",
            )
            .unwrap();
        world
            .observe(
                "notifications.escalation",
                json!({ "reason": format!("{} 3 events", crate::agent::notify::DIGEST_PREFIX) }),
                3_000,
                3_000,
                "notify",
            )
            .unwrap();

        let esc = recent_escalations(&world, 10);
        assert_eq!(esc.len(), 2, "digest is filtered out");
        // Newest first: the presumed-lost (ts 2_000) leads and is critical.
        assert_eq!(esc[0]["ts_ms"], json!(2_000));
        assert_eq!(esc[0]["severity"], json!("critical"));
        assert_eq!(esc[0]["reason"], json!("node n2 presumed lost"));
        assert_eq!(esc[1]["ts_ms"], json!(1_000));

        // status_json surfaces the same feed.
        world
            .observe_as(
                "mesh.n1",
                json!({ "last_type": "reflex" }),
                1_000,
                1_000,
                SOURCE,
                Origin::Observed,
            )
            .unwrap();
        let v = status_json(&world);
        assert_eq!(v["escalations"].as_array().unwrap().len(), 2);
    }
}
